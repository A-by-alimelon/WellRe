//
//  ParticlePeripheral.swift
//  LiveCapturingApp
//
//  Created by A on 2020/11/01.
//

import UIKit
import CoreBluetooth

class ParticlePeripheral: NSObject {
    
}
